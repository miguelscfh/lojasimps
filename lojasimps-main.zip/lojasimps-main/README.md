# Loja do Simpsons
Trabalho de IW2 - Desenvolvendo CRUD (Create Read Uptade Delete - Criação Ler Atualizar Deletar)
Línguagem SQL (Structured Query Language - Linguagem de Consulta Estruturada por IBM)
Equivalente SQL para CRUD -  Comandos:
- Create: 'insert' (Ex: "insert into 'tabela' set ?" - Inserir dados em 'tabela'")
- Read: 'select' (Ex: "select * from 'tabela' - Seleciona os dados em 'tabela'")
- Uptade: 'update' (Ex: "update 'tabela' set ? where id = ? - Atualiza os dados em 'tabela'")
- Delete: 'delete' (Ex: "delete from 'tabela' where id = ? - Apaga o registro em 'tabela'")
- ----------------------------------------------------------------------------------------------
Projeto utilizando o MySQL
